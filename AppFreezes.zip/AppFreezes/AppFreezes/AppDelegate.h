//
//  AppDelegate.h
//  AppFreezes
//
//  Created by R0CKSTAR on 14/9/23.
//  Copyright (c) 2014年 P.D.Q. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

